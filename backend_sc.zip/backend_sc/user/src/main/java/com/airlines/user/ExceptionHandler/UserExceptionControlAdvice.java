package com.airlines.user.ExceptionHandler;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.airlines.user.ExMessage.ExMessage;
import com.airlines.user.Exceptions.UserException;

@ControllerAdvice
public class UserExceptionControlAdvice {

	@ExceptionHandler(UserException.class)
	public ResponseEntity<?> adminExceptionHandler(Exception e) {
		System.out.println(e.getMessage());
		e.printStackTrace();
		return new ResponseEntity<ExMessage>(new ExMessage(e.getMessage(), e.getClass()), org.springframework.http.HttpStatus.NOT_FOUND);
	}
}
