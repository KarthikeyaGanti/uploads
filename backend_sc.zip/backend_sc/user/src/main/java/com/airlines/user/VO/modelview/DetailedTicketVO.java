package com.airlines.user.VO.modelview;

import java.util.List;

import com.airlines.user.VO.FlightVO;
import com.airlines.user.VO.TicketVO;
import com.airlines.user.entity.Passenger;
import com.airlines.user.entity.User;

public class DetailedTicketVO {
	
	private User user;
	private List<Passenger> passengers; 
	private FlightVO flightVO;
	private TicketVO ticketVO;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public List<Passenger> getPassengers() {
		return passengers;
	}
	public void setPassengers(List<Passenger> passengers) {
		this.passengers = passengers;
	}
	public FlightVO getFlightView() {
		return flightVO;
	}
	public void setFlightView(FlightVO flightVO) {
		this.flightVO = flightVO;
	}
	public TicketVO getTicketVO() {
		return ticketVO;
	}
	public void setTicketVO(TicketVO ticketVO) {
		this.ticketVO = ticketVO;
	}	

}
