package com.airlines.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

import com.airlines.user.Exceptions.UserException;
import com.airlines.user.entity.User;
import com.airlines.user.serviceImpl.UserServiceImpl;

@SpringBootApplication
@EnableFeignClients
public class UserApplication implements CommandLineRunner{
	@Autowired
	UserServiceImpl userServiceImpl;
	

	public static void main(String[] args){
		SpringApplication.run(UserApplication.class, args);
	}
	
	public void createUser() throws UserException {
//		User user=new User();
//		user.setuAge(23);
//		user.setuEId("Karthik7@gmail.com");
//		user.setuGender("male");
//		user.setuName("karthik");
//		userServiceImpl.registerUser(user);
	}

	@Override
	public void run(String... args) throws Exception {
//		createUser();
	}
}
