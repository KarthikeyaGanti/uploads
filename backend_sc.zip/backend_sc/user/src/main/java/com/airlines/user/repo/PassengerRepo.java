package com.airlines.user.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.airlines.user.entity.Passenger;

public interface PassengerRepo extends JpaRepository<Passenger, Integer>{

}
