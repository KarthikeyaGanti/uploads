package com.airlines.user.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.springframework.beans.factory.annotation.Autowired;

@Entity
public class User {

	@Id
	@Column(unique =true)
	private String uEId;
	private String uName;
	private Integer uAge;
	private String uGender;
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getuEId() {
		return uEId;
	}
	public void setuEId(String uEId) {
		this.uEId = uEId;
	}
	public Integer getuAge() {
		return uAge;
	}
	public void setuAge(Integer uAge) {
		this.uAge = uAge;
	}
	public String getuGender() {
		return uGender;
	}
	public void setuGender(String uGender) {
		this.uGender = uGender;
	}
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public User(String uName, String uEId, Integer uAge, String uGender) {
		super();
		this.uName = uName;
		this.uEId = uEId;
		this.uAge = uAge;
		this.uGender = uGender;
	}
	
	
	
}
