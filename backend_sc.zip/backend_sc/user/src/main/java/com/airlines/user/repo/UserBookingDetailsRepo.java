package com.airlines.user.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.airlines.user.entity.UserBookingDetails;

public interface UserBookingDetailsRepo extends JpaRepository<UserBookingDetails,Integer>{

}
