package com.airlines.user.client;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.airlines.user.VO.FlightVO;

@FeignClient("FlightService")
public interface UserFlightClient {

	@GetMapping("/flights/searchflights")
	public List<FlightVO> searchFlights(@RequestParam String date,@RequestParam String time,@RequestParam String from,@RequestParam String to,@RequestParam String tripType);

	@GetMapping("/flights/byId")
	public FlightVO getFlightById(@RequestParam String FID);

}
