package com.airlines.user.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.airlines.user.VO.TicketVO;
import com.airlines.user.entity.User;

@FeignClient("BookingService")
public interface UserBookingClient {
	
	@PostMapping("/booking/bookticket")
	public String bookTicket(@RequestBody User user,@RequestParam String FID,@RequestParam Integer no_of_seats,@RequestParam List<String> seats,@RequestParam String meal);

	@GetMapping("/booking/getticket")
	public TicketVO getTicketByPNR(@RequestParam String pnrNumber);
	
	@GetMapping("/booking/getAllTickets")
	public List<TicketVO> getTickets(@RequestParam String uEID);
	
	@PostMapping("/booking/cancelticket")
	public String cancelTicket(@RequestParam String uEID,@RequestParam String pnrNumber);
		
	

}

