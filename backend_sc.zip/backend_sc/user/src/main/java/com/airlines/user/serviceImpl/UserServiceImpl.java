package com.airlines.user.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.airlines.user.Exceptions.UserException;
import com.airlines.user.VO.FlightVO;
import com.airlines.user.VO.TicketVO;
import com.airlines.user.VO.UserVO;
import com.airlines.user.VO.modelview.DetailedTicketVO;
import com.airlines.user.VO.modelview.FlightView;
import com.airlines.user.entity.Passenger;
import com.airlines.user.entity.User;
import com.airlines.user.entity.UserBookingDetails;
import com.airlines.user.repo.PassengerRepo;
import com.airlines.user.repo.UserBookingDetailsRepo;
import com.airlines.user.repo.UserRepo;

@Service
public class UserServiceImpl{

	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	PassengerRepo passengerRepo;
	
	@Autowired
	UserBookingDetailsRepo bookingDetailsRepo;
	
	@Autowired
	JavaMailSender mailSender;
	
	public String viewHistorytOfUser(String emailId) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public String downloadTicketOfUser(String emailId) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public String cancelTicketByUser(String emailId) {
		// TODO Auto-generated method stub
		return null;
	}


	public DetailedTicketVO viewBookedTicketOfUser(TicketVO ticketVO, FlightVO flightVO) {
		DetailedTicketVO detailedTicketVO= new DetailedTicketVO();
		Optional<User> optional=userRepo.findById(ticketVO.getuEID());
		List<Passenger> passengers_db=passengerRepo.findAll();
		List<Passenger> passengers=new ArrayList<Passenger>();
		for(Passenger p: passengers_db) {
			if(p.getuEID().equals(ticketVO.getuEID())&& p.getPnrNumber().equals(ticketVO.getPnrNumber())) {
				passengers.add(p);
			}
		}
		detailedTicketVO.setTicketVO(ticketVO);
		detailedTicketVO.setUser(optional.get());
		detailedTicketVO.setFlightView(flightVO);
		detailedTicketVO.setPassengers(passengers);
		return detailedTicketVO;
	}
	
	public User registerUser(UserVO user) throws UserException {
		List<User> users=getAllUsers();
		for(User u:users) {
			if(u.getuEId().equals(user.getuEId()))
					throw new UserException("User Already exists");
		}
		 
			User userEntiry= new User();
			userEntiry.setuEId(user.getuEId());
			userRepo.save(userEntiry);
			userEntiry.setuAge(user.getuAge());
			userEntiry.setuGender(user.getuName());
			userEntiry.setuName(user.getuName());
			return userRepo.save(userEntiry);
	}
	
	public boolean registerUserInDB(UserVO user) throws UserException
	{
		List<User> users= getAllUsers();
		for(User u:users) {
			if (u.getuEId().equals(user.getuEId()))
				return true;
		}
		User User=registerUser(user);
		return true;
	}
	
	public List<User> getAllUsers(){
		return userRepo.findAll();
	}

	
	public boolean userLogin(String EID) {
		// TODO Auto-generated method stub
		return false;
	}
 	
	public User getUserById(String EID) {
		 Optional<User> optional= userRepo.findById(EID);
		return optional.get();
	}
	
	public List<FlightView> userView(List<FlightVO> flightList){
		List<FlightView> searchList= new ArrayList<>();		
		for(FlightVO flightVO: flightList) {
			FlightView flightView = new FlightView();
			flightView.setfID(flightVO.getfID());
			flightView.setfName(flightVO.getfName());
			flightView.setFromPlace(flightVO.getFromPlace());
			flightView.setStart_date(flightVO.getStart_date());
			flightView.setDeparture_time(flightVO.getDeparture_time());
			flightView.setToPlace(flightVO.getToPlace());
			flightView.setEnd_date(flightVO.getEnd_date());
			flightView.setDrop_time(flightVO.getBoarding_time());
			flightView.setPrice(flightVO.getPrice());
			searchList.add(flightView);
		}
		return searchList;
	}
	
	public List<String> convertSeat(String[] seat_numbers){
		List<String> seatNumberList=new ArrayList<String>();
		for(int i=0;i<seat_numbers.length;i++) {
			seatNumberList.add(seat_numbers[i]);
		}
		return seatNumberList;
	}
	public String saveDetails(String message,String FID,UserVO user) {
		UserBookingDetails bookingDetails= new UserBookingDetails();
		if(message.contains("PNR")) {
			List<Integer> Ids= new ArrayList();
			bookingDetails.setuEID(user.getuEId());
			bookingDetails.setFID(FID);
			bookingDetails.setPnrNumber(message);
			List<Passenger> passengers=passengerRepo.findAll();
			for(Passenger p: passengers) {
				if(p.getuEID().equals(user.getuEId()))
					Ids.add(p.getId());
			}
			bookingDetails.setPassengerIds(Ids);
			bookingDetailsRepo.save(bookingDetails);
			return message;
		}
		return message;
	}
	
	public User userVOtoUser(UserVO userVO) {
		User user = new User();
		user.setuName(userVO.getuName());
		user.setuAge(userVO.getuAge());
		user.setuGender(userVO.getuGender());
		user.setuEId(userVO.getuEId());
		return user;
	}
	
	public int cancelTicket(String uEID,String pnrNumber) {
		List<UserBookingDetails> bookingDetails=bookingDetailsRepo.findAll();
		for(UserBookingDetails ub:bookingDetails) {
			if(ub.getuEID().equals(uEID)&& ub.getPnrNumber().equals(pnrNumber)) {
				bookingDetailsRepo.delete(ub);
				return 1;
			}		
		}
		return 0;
	}
	
    private static final String TOPIC = "block-airline-topic";
    @KafkaListener(topics = TOPIC, groupId="group_id", containerFactory = "userKafkaListenerFactory")
	public void sendMailForBlockedAirlines(String fID) {
    	System.out.println(fID);
    	List<UserBookingDetails> bookings=bookingDetailsRepo.findAll();
    	for(UserBookingDetails ub: bookings) {
    		if(ub.getFID().equalsIgnoreCase(fID)) {
    			String body= "Booking cancelled for the user" + ub.getuEID() +"with PNR" + ub.getPnrNumber()+ "as airline service got cancelled due to bad circumstances";
    			String toEmail="karthikeyaganti7@gmail.com";
    			String subject="FLIGHT CANCELLED";
    			sendMail(toEmail, subject, body);
    		}
    	}	
	}
    
    public void sendMail(String toEmail,String subject,String body) {
    	SimpleMailMessage message= new SimpleMailMessage();
    	message.setFrom("karthikeyaganti7@gmail.com");
    	message.setTo(toEmail);
    	message.setText(body);
    	message.setSubject(subject);
    	mailSender.send(message);
    	System.err.println("mail sent");
    	   	
    }
}