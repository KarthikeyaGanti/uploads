package com.airlines.user.validation;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.airlines.user.entity.User;
import com.airlines.user.repo.UserRepo;

@Component
public class UserValidation {
	
	@Autowired
	UserRepo repo;
	
	public Integer validateUEID(String uEID) {
		Optional<User> optional= repo.findById(uEID);
		if(optional.isEmpty())
			return 0;
		return 1;
		
	}

}
