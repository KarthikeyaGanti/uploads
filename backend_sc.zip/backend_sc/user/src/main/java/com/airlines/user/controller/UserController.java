package com.airlines.user.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airlines.user.Exceptions.UserException;
import com.airlines.user.VO.FlightVO;
import com.airlines.user.VO.TicketVO;
import com.airlines.user.VO.UserVO;
import com.airlines.user.VO.modelview.DetailedTicketVO;
import com.airlines.user.VO.modelview.FlightView;
import com.airlines.user.client.UserBookingClient;
import com.airlines.user.client.UserFlightClient;
import com.airlines.user.entity.Passenger;
import com.airlines.user.entity.User;
import com.airlines.user.serviceImpl.PassengerServiceImpl;
import com.airlines.user.serviceImpl.UserServiceImpl;
import com.airlines.user.validation.UserValidation;

import io.swagger.v3.core.util.Json;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserServiceImpl userService;
	
	@Autowired
	UserValidation userValidation;
	
	@Autowired
	PassengerServiceImpl passengerService;
	
	@Autowired
	private UserFlightClient client;
	
	@Autowired
	private UserBookingClient bookingClient;
	
	@PostMapping("/register")
	public String registerUser(@RequestBody UserVO user) throws UserException {
			System.err.println(user);
			userService.registerUser(user);
			return "User Successfully Registered";
	}
	
	@GetMapping("/users")
	public List<User> getAllUsers(){
		return userService.getAllUsers();
	}
	
	@GetMapping("/search/{date}/{time}/{from}/{to}/{tripType}")
	public List<FlightView> searchFlights(@PathVariable String date,@PathVariable String time,@PathVariable String from,@PathVariable String to,@PathVariable String tripType){
		System.err.println(time);
		System.err.println(date);
		List<FlightVO> flightList= client.searchFlights(date,time,from,to,tripType);
		return userService.userView(flightList);
	}
	
	@PostMapping("/bookticket/{FID}/{no_of_seats}/{seat_numbers}/{meal}")	
	public String bookTicketForUSer(@RequestBody UserVO user,@PathVariable String FID,@PathVariable Integer no_of_seats,@PathVariable String[] seat_numbers,@PathVariable String meal) throws UserException {
		String message="";
		System.err.println(user.getPassengerVOs());
		List<String> seats=userService.convertSeat(seat_numbers);
		if(userService.registerUserInDB(user)) {
			User user1=userService.userVOtoUser(user);
			message= bookingClient.bookTicket(user1, FID, no_of_seats, seats, meal);
			passengerService.savePassenger(user,message);
			userService.saveDetails(message,FID,user);
		}
		return Json.pretty(message);
	}
	
	@GetMapping("/byId")
	public User getUserById(String EID) {
		return userService.getUserById(EID);
	}
	
	@GetMapping("/viewbookedticket/{uEID}/{pnrNumber}")
	public DetailedTicketVO viewBookedTIcket(@PathVariable String uEID,@PathVariable String pnrNumber) {
		TicketVO ticketVO= bookingClient.getTicketByPNR(pnrNumber);
		String FID=ticketVO.getFlightID();
		FlightVO flightVO=client.getFlightById(FID);
		return userService.viewBookedTicketOfUser(ticketVO, flightVO);
	}
	
	@GetMapping("/viewhistory/{uEID}")
	public List<DetailedTicketVO> getBookingHistory(@PathVariable String uEID){
		List<DetailedTicketVO> detailedTIcketHistory= new ArrayList<DetailedTicketVO>();
		List<TicketVO> ticketsBooked=bookingClient.getTickets(uEID);
		for(TicketVO t:ticketsBooked ) {
			String FID=t.getFlightID();
			FlightVO flightVO=client.getFlightById(FID);
			detailedTIcketHistory.add(userService.viewBookedTicketOfUser(t, flightVO));
		}
		
		return detailedTIcketHistory;
	}
	
	@PostMapping("/cancelticket/{uEID}/{pnrNumber}")
	public String cancelTicket(@PathVariable String uEID,@PathVariable String pnrNumber) {
		String message="";
		int i;
//		Integer v=userValidation.validateUEID(uEID);
//		if(v==0)
//			return Json.pretty("Enter Valid Email ID");
//		else {
				message=bookingClient.cancelTicket(uEID,pnrNumber);
				System.out.println(message);
				if(message.equalsIgnoreCase("success")) {
					i=userService.cancelTicket(uEID, pnrNumber);
					if(i==1)
						return Json.pretty("Booking Cancelled Successfully");
					return Json.pretty("Booking Details no longer available");
				}
				else if (message.equalsIgnoreCase("no"))
					return Json.pretty("Enter Valid PNR Number");
				return Json.pretty("Booking Cannot be Cancelled as time is less than 24hrs");	
		
	}
}
