package com.airlines.user.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


@Entity
public class UserBookingDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer Id;
	private String pnrNumber;
	private String uEID;
	private String FID;
	@ElementCollection
	private List<Integer> passengerIds;

	public List<Integer> getPassengerIds() {
		return passengerIds;
	}

	public void setPassengerIds(List<Integer> passengerIds) {
		this.passengerIds = passengerIds;
	}
	public String getuEID() {
		return uEID;
	}

	public void setuEID(String uEID) {
		this.uEID = uEID;
	}

	public String getFID() {
		return FID;
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer Id) {
		this.Id = Id;
	}

	public void setFID(String fID) {
		FID = fID;
	}

	public String getPnrNumber() {
		return pnrNumber;
	}

	public void setPnrNumber(String pnrNumber) {
		this.pnrNumber = pnrNumber;
	}


	}

