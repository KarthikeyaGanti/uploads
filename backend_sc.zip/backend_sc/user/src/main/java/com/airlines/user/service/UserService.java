package com.airlines.user.service;


import java.time.LocalDateTime;
import java.util.List;

import com.airlines.user.VO.FlightVO;
import com.airlines.user.entity.User;

public interface UserService {

	/**
	 * returns list of flights present on the search criteria of user 
	 * @param dateTime
	 * @param from
	 * @param to
	 * @param tripType
	 * @return
	 */
	public List<FlightVO> searchFlightByUser(LocalDateTime dateTime,String from,String to,String tripType);
	
	/**
	 * returns the history of tickets booked by user using email ID.
	 * @param emailId
	 * @return
	 */
	public String viewHistorytOfUser(String emailId);
	
	/**
	 * download ticket of user 
	 * @param emailId
	 * @return
	 */
	public String downloadTicketOfUser(String emailId);

	
	/**
	 * used to cancel ticket booked by user prior to 24 hrs before date of journey
	 * @param emailId
	 * @return
	 */
	public String cancelTicketByUser(String emailId);
	
	/**
	 * used to book a selected flight and PNR (String) number is returned on successful booking
	 * user should be able to download ticket  
	 * @param flight
	 * @param name
	 * @param user
	 * @return
	 */
	public String bookTicketByUser(FlightVO flight,User user,Integer no_of_seats,String meal);
	
	
	/**
	 * with pnr numbe user should be able to view the details of ticket booked.
	 * @param emailId
	 * @param pnrNumber
	 * @return
	 */
	public String viewBookedTicketOfUser(String emailId,String pnrNumber);
	
	public boolean userLogin(String EID);
	
	public User getUserById(String EID);
	
}
