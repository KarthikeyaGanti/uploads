package com.airlines.user.VO;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

public class UserVO {
	private String uEId;
	private String uName;
	private Integer uAge;
	private String uGender;
	private List<PassengerVO> passengerVOs;
	public String getuEId() {
		return uEId;
	}
	public void setuEId(String uEId) {
		this.uEId = uEId;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public Integer getuAge() {
		return uAge;
	}
	public void setuAge(Integer uAge) {
		this.uAge = uAge;
	}
	public String getuGender() {
		return uGender;
	}
	public void setuGender(String uGender) {
		this.uGender = uGender;
	}
	public List<PassengerVO> getPassengerVOs() {
		return passengerVOs;
	}
	public void setPassengerVOs(List<PassengerVO> passengerVOs) {
		this.passengerVOs = passengerVOs;
	}
}
