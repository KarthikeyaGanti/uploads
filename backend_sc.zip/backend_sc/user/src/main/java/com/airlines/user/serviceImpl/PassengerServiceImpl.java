package com.airlines.user.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airlines.user.VO.PassengerVO;
import com.airlines.user.VO.UserVO;
import com.airlines.user.entity.Passenger;
import com.airlines.user.repo.PassengerRepo;

@Service
public class PassengerServiceImpl {
	
	@Autowired
	PassengerRepo passengerRepo;
	
	public void savePassenger(UserVO user,String message) {
		List<PassengerVO> passengers=user.getPassengerVOs();
		System.err.println(passengers);
		if(message.contains("PNR")) {
			for(PassengerVO p: passengers) {
				System.err.println(p);
				Passenger passenger= new Passenger();
				passenger.setuEID(user.getuEId());
				passenger.setPnrNumber(message);
				passenger.setPassengerName(p.getPassengerName());
				passenger.setPassengerAge(p.getPassengerAge());
				passenger.setPassengerGender(p.getPassengerGender());
				passengerRepo.save(passenger);
			}
		}
	}
	
	
}
