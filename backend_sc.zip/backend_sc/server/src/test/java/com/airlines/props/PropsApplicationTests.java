// package com.airlines.props;

// import org.junit.jupiter.api.Test;
// import org.springframework.boot.test.context.SpringBootTest;

// @SpringBootTest
// class PropsApplicationTests {

// 	@Test
// 	void contextLoads() {
// 	}

// }
