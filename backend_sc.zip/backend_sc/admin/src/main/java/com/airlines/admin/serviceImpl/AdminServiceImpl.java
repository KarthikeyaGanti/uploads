package com.airlines.admin.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.airlines.admin.Exception.AdminException;
import com.airlines.admin.entity.Admin;
import com.airlines.admin.repo.AdminRepo;
import com.airlines.admin.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	private AdminRepo adminRepo;

	@Override
	public void adminLogin(Admin admin) throws AdminException {
		Optional<Admin> optional=adminRepo.findById(admin.getAdimUser().toLowerCase());
		if(optional.isEmpty())
			throw new AdminException("Invalid Admin User");
		else if(!optional.get().getAdminPassword().equals(admin.getAdminPassword()))
			throw new AdminException("Invalid Password");
		else
			System.out.println("Admin login Successful");	
	}

	@Override
	public void adminLogout() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String saveFlightIDs(String FID) {
		//code for saving FIDS into admin db
		return "FLIGHT ADDED WITH ID :"+FID;
	}

}
