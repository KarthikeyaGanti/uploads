package com.airlines.admin.vo;

import java.time.LocalDate;
import java.time.LocalTime;

import com.fasterxml.jackson.annotation.JsonFormat;

public class FlightVO {
	private String fID;
	private String fName;
	private String fromPlace;
	private String toPlace;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private LocalDate start_date;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="HH:mm")
	private LocalTime departure_time;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private LocalDate end_date;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="HH:mm")
	private LocalTime drop_time;
	private String scheduled_days;
	private Integer business_Seats;
	private Integer non_Business_seats;
	private Double price;
	private Integer no_Of_Rows;
	private String meal;
	public String getfID() {
		return fID;
	}
	public void setfID(String fID) {
		this.fID = fID;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getFromPlace() {
		return fromPlace;
	}
	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}
	public String getToPlace() {
		return toPlace;
	}
	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}
	public LocalDate getStart_date() {
		return start_date;
	}
	public void setStart_date(LocalDate start_date) {
		this.start_date = start_date;
	}
	public LocalTime getDeparture_time() {
		return departure_time;
	}
	public void setDeparture_time(LocalTime departure_time) {
		this.departure_time = departure_time;
	}
	public LocalDate getEnd_date() {
		return end_date;
	}
	public void setEnd_date(LocalDate end_date) {
		this.end_date = end_date;
	}
	public LocalTime getBoarding_time() {
		return drop_time;
	}
	public void setBoarding_time(LocalTime drop_time) {
		this.drop_time = drop_time;
	}
	public String getScheduled_days() {
		return scheduled_days;
	}
	public void setScheduled_days(String scheduled_days) {
		this.scheduled_days = scheduled_days;
	}
	public Integer getBusiness_Seats() {
		return business_Seats;
	}
	public void setBusiness_Seats(Integer business_Seats) {
		this.business_Seats = business_Seats;
	}
	public Integer getNon_Business_seats() {
		return non_Business_seats;
	}
	public void setNon_Business_seats(Integer non_Business_seats) {
		this.non_Business_seats = non_Business_seats;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Integer getNo_Of_Rows() {
		return no_Of_Rows;
	}
	public void setNo_Of_Rows(Integer no_Of_Rows) {
		this.no_Of_Rows = no_Of_Rows;
	}
	public String getMeal() {
		return meal;
	}
	public void setMeal(String meal) {
		this.meal = meal;
	}

	
	}