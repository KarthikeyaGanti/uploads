package com.airlines.admin.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.airlines.admin.vo.AirlinesVO;
import com.airlines.admin.vo.FlightVO;

@FeignClient("FlightService")
public interface AdminFlightClient {
	
	@PostMapping("/flights/addairline")
	public String addAirLine(@RequestBody AirlinesVO airlinesVO);
	
	@PostMapping("/flights/blockairline")
	public String blockAirLine(@RequestParam String airLineID);

	@PostMapping("/flights/unblockairline")
	public String unblockAirLine(@RequestParam String airLineID);

	@PostMapping("/flights/addFlight")
	public String addFlight(@RequestBody FlightVO flight);
	
	@GetMapping("flights/allairlines")
	public List<AirlinesVO> getAllAirLines();
	
	
}
