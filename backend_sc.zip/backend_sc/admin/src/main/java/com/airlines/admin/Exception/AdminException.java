package com.airlines.admin.Exception;

public class AdminException extends Exception{

	public AdminException() {
		super();
	}

	public AdminException(String message) {
		super(message);
	}
	
	

}
