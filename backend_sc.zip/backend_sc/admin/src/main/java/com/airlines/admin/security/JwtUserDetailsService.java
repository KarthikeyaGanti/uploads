package com.airlines.admin.security;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.airlines.admin.entity.Admin;
import com.airlines.admin.repo.AdminRepo;

@Service
public class JwtUserDetailsService implements UserDetailsService {

	@Autowired
	AdminRepo adminRepo;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		//we have to modify to get data from data base 
		List<Admin> admins= adminRepo.findAll();
		for (Admin admin: admins) {
			if (admin.getAdimUser().equalsIgnoreCase(username)) {
				Set<SimpleGrantedAuthority> authorities = new HashSet<>();
		        authorities.add(new SimpleGrantedAuthority("ROLE_" + "ADMIN"));
				return new User(admin.getAdimUser(), "{noop}"+admin.getAdminPassword(),authorities);
			}
		}
			throw new UsernameNotFoundException("User not found with username: " + username);
		
	}
}
