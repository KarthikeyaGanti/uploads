package com.airlines.booking.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.cloud.openfeign.CollectionFormat;

@Entity
public class SeatsBooked {

	@Id
	private String FID;
	@ElementCollection
	private List<String> business_seats_booked;
	@ElementCollection
	private List<String> non_business_seats_booked;
	public String getFID() {
		return FID;
	}
	public void setFID(String fID) {
		FID = fID;
	}
	public List<String> getBusiness_seats_booked() {
		return business_seats_booked;
	}
	public void setBusiness_seats_booked(List<String> business_seats_booked) {
		this.business_seats_booked = business_seats_booked;
	}
	public List<String> getNon_business_seats_booked() {
		return non_business_seats_booked;
	}
	public void setNon_business_seats_booked(List<String> non_business_seats_booked) {
		this.non_business_seats_booked = non_business_seats_booked;
	};

}
