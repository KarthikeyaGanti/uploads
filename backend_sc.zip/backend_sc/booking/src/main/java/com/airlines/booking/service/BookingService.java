package com.airlines.booking.service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import com.airlines.booking.VO.UserVO;

public interface BookingService {

	/**
	 * returns a PNR number on successful booking of ticket
	 * @param flight
	 * @param user
	 * @return
	 */
	public String bookTicketByUser(String FID, UserVO user,Integer no_Of_Seats,String meal,List<String> seats);

	/**
	 * returns details of ticket using email id and pnr number 
	 * @param emailId
	 * @param pnrNumber
	 * @return
	 */
}
