package com.airlines.booking.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.airlines.booking.entity.SeatsBooked;

public interface SeatsRepo extends JpaRepository<SeatsBooked, String> {

}
