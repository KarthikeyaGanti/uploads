package com.airlines.booking.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.airlines.booking.entity.Ticket;

public interface BookingRepo extends JpaRepository<Ticket, String>{

}
