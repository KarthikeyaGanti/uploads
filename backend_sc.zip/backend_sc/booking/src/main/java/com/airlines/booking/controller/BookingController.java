package com.airlines.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.airlines.booking.VO.UserVO;
import com.airlines.booking.entity.Ticket;
import com.airlines.booking.serviceImpl.BookingServiceImpl;

@RestController
@RequestMapping("/booking")
public class BookingController {

	@Autowired
	private BookingServiceImpl bookingService;
	
	@PostMapping("/bookticket")
	public String bookTicket(@RequestBody UserVO user,@RequestParam String FID,@RequestParam Integer no_of_seats,@RequestParam List<String> seats,@RequestParam String meal) {
		return bookingService.bookTicketByUser(FID, user, no_of_seats, meal, seats);
	}

	@GetMapping("/getticket")
	public Ticket getTicketByPNR(@RequestParam String pnrNumber) {
		System.err.println("iam here");
		return bookingService.getTicketByPNR(pnrNumber);
	}
	@GetMapping("/getAllTickets")
	public List<Ticket> getTickets(@RequestParam String uEID){
		return bookingService.getTickets(uEID);
	}
	
	@PostMapping("/cancelticket")
	public String cancelTicket(@RequestParam String uEID,@RequestParam String pnrNumber) {
		return bookingService.cancelTicket(uEID,pnrNumber);
	}
	

}
