package com.airlines.flight.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.airlines.flight.entity.Flight;
/**
 * 
 * @author cogjava1790
 * used for performing database activites 
 *
 */
public interface FlightsRepo extends JpaRepository<Flight, String> {

}
