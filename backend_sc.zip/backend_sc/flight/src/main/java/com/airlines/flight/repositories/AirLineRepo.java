package com.airlines.flight.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.airlines.flight.entity.Airlines;

public interface AirLineRepo extends JpaRepository<Airlines, String>{

}
