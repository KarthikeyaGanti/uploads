package com.airlines.flight.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.airlines.flight.VO.AirlineVO;
import com.airlines.flight.airlineexception.AirLineException;
import com.airlines.flight.entity.Airlines;
import com.airlines.flight.entity.Flight;
import com.airlines.flight.repositories.AirLineRepo;
import com.airlines.flight.repositories.FlightsRepo;
import com.airlines.flight.service.AirLineService;

@Service
public class AirLineServiceImpl implements AirLineService{
	@Autowired
	private AirLineRepo airLineRepo;
	
	@Autowired
	private FlightsRepo flightsRepo;

	@Override
	public String addAirLine(Airlines airlines) throws AirLineException{
		
		Integer length =airlines.getAirLineName().length();
		String airID= airlines.getAirLineName().substring(0, 3);
		if(airLineRepo.findById(airID).isEmpty())
		{
			airlines.setAirLineId(airID);
			airLineRepo.save(airlines);
			return "AIRLINE ADDED : "+airlines.getAirLineName()+" WITH ID :" +airlines.getAirLineId();
		}
		else
			return "AIRLINE ALREADY EXISTS";
	}
	
	@Autowired
    private KafkaTemplate<String, String> kafkaTemplate;
	private static final String TOPIC = "block-airline-topic";
    @Override
    public String blockAirLine(String airLineID) {
		Optional<Airlines> optional= airLineRepo.findById(airLineID);
		Airlines airlines=optional.get();
		if(airlines.getAirLineStatus().equalsIgnoreCase("blocked"))
			return "AIRLINE ALREADY BLOCKED";
		else
		{
			airlines.setAirLineStatus("blocked");
			airLineRepo.save(airlines);
			List<Flight> flights= flightsRepo.findAll();
			for(Flight f:flights) {
				if(f.getfName().equalsIgnoreCase(airlines.getAirLineName())) {
					System.out.println("fid for kafka is" + f.getfID());
			        kafkaTemplate.send(TOPIC,f.getfID());
				}
			}
			return "AIRLINE BLOCKED";
		}
	}
	@Override
	public String unblockAirLine(String airLineID) {
		Optional<Airlines> optional= airLineRepo.findById(airLineID);
		Airlines airlines=optional.get();
		if(airlines.getAirLineStatus().equalsIgnoreCase("active"))
			return "AIRLINE ALREADY ACTIVE";
		else
		{
			airlines.setAirLineStatus("active");
			airLineRepo.save(airlines);
			return "AIRLINE UNBLOCKED";
		}
	}
	public Boolean getAirLine(String airLineName){
		List<Airlines> airlines=airLineRepo.findAll();
		for(Airlines airlines2:airlines) {
			if(airlines2.getAirLineName().equalsIgnoreCase(airLineName))
				return true;
		}
		return false;
	}
	@Override
	public String getStatusOfAirline(String airLineName) {
		List<Airlines> airlines= airLineRepo.findAll();
		 if(airlines.isEmpty())
			 return "NO AIRLINE";
		 else {
			 for (Airlines a : airlines) {
				if(a.getAirLineName().equalsIgnoreCase(airLineName))
					return a.getAirLineStatus();
			}
		 }
		 return "NO AIRLINE";
	}
	@Override
	public List<AirlineVO> getAllAirLines() {
		List<Airlines> airlines= airLineRepo.findAll();
		List<AirlineVO> airlineVos=new ArrayList(); 
		for(Airlines a:airlines) {
			AirlineVO airlineVO= new AirlineVO();
			airlineVO.setAirLineID(a.getAirLineId());
			airlineVO.setAirLineName(a.getAirLineName());
			airlineVO.setAirLineStatus(a.getAirLineStatus());
			airlineVos.add(airlineVO);
		}
		return airlineVos;
	}
	
//    private static final String TOPIC = "addAirline-topic";
//    @KafkaListener(topics = TOPIC, groupId="group_id", containerFactory = "userKafkaListenerFactory")
//	public void kafkaBOlckedAirline(Airlines String) {
//        System.out.println("Consumed JSON Message: " + String);
//    }
//		
}
