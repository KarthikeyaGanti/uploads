package com.airlines.flight.service;

import java.time.LocalDateTime;
import java.util.List;

import com.airlines.flight.entity.Airlines;
import com.airlines.flight.entity.Flight;


public interface FlightService {
	
	/*
	 * adds flight and return a String with successful message along with ID
	 */
	public  String addFlight(Flight flight);

	
	/*
	 * returns list of flights based on passed criteria 
	 */
	public List<Flight> searchFlights (String date,String time,String from,String to,String tripType);

	/*
	 * it takes flight and flightID as parameters, updates the flight info and returns a messafe
	 */
	public String updateFlight(Flight flight,int Id);
	
	/*
	 * it deletes flight present in the given Id
	 */
	public String removeFlight(int Id);
	
	/*
	 * return all flights present in database for test purpose
	 */
	public List<Flight> getAllFlights();
	
	public Flight getFlightById(String FID);
		
}