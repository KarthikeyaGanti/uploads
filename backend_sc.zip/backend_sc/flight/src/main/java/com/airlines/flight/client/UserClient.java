package com.airlines.flight.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.airlines.flight.VO.UserVO;

@FeignClient("UserService")//application name given in app.props

public interface UserClient {

	@GetMapping("/users")
	List<UserVO> getUsers();
}
