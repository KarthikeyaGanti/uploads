package com.airlines.flight.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Airlines {

	@Id
	private String airLineId;
	private String airLineName;
	private String airLineStatus;

	public String getAirLineStatus() {
		return airLineStatus;
	}

	public void setAirLineStatus(String airLineStatus) {
		this.airLineStatus = airLineStatus;
	}

	public String getAirLineId() {
		return airLineId;
	}

	public void setAirLineId(String airLineId) {
		this.airLineId = airLineId;
		this.airLineStatus=airLineStatus;
	}

	public String getAirLineName() {
		return airLineName;
	}

	public void setAirLineName(String airLineName) {
		this.airLineName = airLineName;
	}

	public Airlines(String airLineName,String airLineStatus) {
		super();
		this.airLineName = airLineName;
		this.airLineStatus=airLineStatus;
	}

	public Airlines() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
