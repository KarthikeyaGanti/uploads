package com.airlines.flight.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.airlines.flight.VO.AirlineVO;
import com.airlines.flight.airlineexception.AirLineException;
import com.airlines.flight.entity.Airlines;
import com.airlines.flight.entity.Flight;
import com.airlines.flight.service.AirLineService;
import com.airlines.flight.serviceImpl.FlightServiceImpl;

@RestController
@CrossOrigin
@RequestMapping("/flights")
public class FlightController {

	@Autowired
	private FlightServiceImpl flightService;
	@Autowired 
	private AirLineService airLineService;
	
	@GetMapping("/allairlines")
	public List<AirlineVO>getAllAirLines(){
		return airLineService.getAllAirLines();
	}
	
	@PostMapping("/addairline")
	public String addAirLine(@RequestBody Airlines airlines) throws AirLineException {
		System.out.println(airlines.getAirLineName());
		return airLineService.addAirLine(airlines);
	}
	@PostMapping("/blockairline")
	public String blockAirLine(@RequestParam String airLineID) throws AirLineException {
		return airLineService.blockAirLine(airLineID);
	}
	@PostMapping("/unblockairline")
	public String unblockAirLine(@RequestParam String airLineID) throws AirLineException {
		return airLineService.unblockAirLine(airLineID);
	}
	
	@PostMapping("/addFlight")
	public String addFlight(@RequestBody Flight flight) {
		return flightService.addFlight(flight);
	}
	
	/////////////// admin module ends////////////////////////
	
	@GetMapping("/allflights")
	public List<Flight> getAllFlights(){
		return flightService.getAllFlights();
	}
	
	@GetMapping("/searchflights")
	public List<Flight> searchFlighs(@RequestParam String date,@RequestParam String time,@RequestParam String from,@RequestParam String to,@RequestParam String tripType){
		return flightService.searchFlights(date,time, from, to, tripType);
	}
	
	@GetMapping("/byId")
	public Flight getFlightById(@RequestParam String FID) {
		System.err.println("inflight controller");
		return flightService.getFlightById(FID);
	}
}
