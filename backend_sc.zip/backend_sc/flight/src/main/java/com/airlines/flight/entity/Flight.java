package com.airlines.flight.entity;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.print.attribute.standard.DateTimeAtCompleted;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;


@Entity
//@Table(name = "Flight")
public class Flight {
	@Id
	private String fID;
	private String fName;
	private String fromPlace;
	private String toPlace;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private LocalDate start_date;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="HH:mm")
	private LocalTime departure_time;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private LocalDate end_date;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="HH:mm")
	private LocalTime drop_time;
	private String scheduled_days;
	private Integer business_Seats;
	private Integer non_Business_seats;
	private Double price;
	private Integer no_Of_Rows;
	private String meal;
	public String getfID() {
		return fID;
	}
	public void setfID(String fID) {
		this.fID = fID;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getFromPlace() {
		return fromPlace;
	}
	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}
	public String getToPlace() {
		return toPlace;
	}
	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}
	
		public String getScheduled_days() {
		return scheduled_days;
	}
	public LocalDate getStart_date() {
			return start_date;
		}
		public void setStart_date(LocalDate start_date) {
			this.start_date = start_date;
		}
		public LocalTime getDeparture_time() {
			return departure_time;
		}
		public void setDeparture_time(LocalTime departure_time) {
			this.departure_time = departure_time;
		}
		public LocalDate getEnd_date() {
			return end_date;
		}
		public void setEnd_date(LocalDate end_date) {
			this.end_date = end_date;
		}
		public LocalTime getDrop_time() {
			return drop_time;
		}
		public void setDrop_time(LocalTime drop_time) {
			this.drop_time = drop_time;
		}
	public void setScheduled_days(String scheduled_days) {
		this.scheduled_days = scheduled_days;
	}
	public Integer getBusiness_Seats() {
		return business_Seats;
	}
	public void setBusiness_Seats(Integer business_Seats) {
		this.business_Seats = business_Seats;
	}
	public Integer getNon_Business_seats() {
		return non_Business_seats;
	}
	public void setNon_Business_seats(Integer non_Business_seats) {
		this.non_Business_seats = non_Business_seats;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Integer getNo_Of_Rows() {
		return no_Of_Rows;
	}
	public void setNo_Of_Rows(Integer no_Of_Rows) {
		this.no_Of_Rows = no_Of_Rows;
	}
	public String getMeal() {
		return meal;
	}
	public void setMeal(String meal) {
		this.meal = meal;
	}
	public Flight(String fName, String fromPlace, String toPlace, LocalDate start_date, LocalTime departure_time,
			LocalDate end_date, LocalTime drop_time, String scheduled_days, Integer business_Seats,
			Integer non_Business_seats, Double price, Integer no_Of_Rows, String meal) {
		super();
		this.fName = fName;
		this.fromPlace = fromPlace;
		this.toPlace = toPlace;
		this.start_date = start_date;
		this.departure_time = departure_time;
		this.end_date = end_date;
		this.drop_time = drop_time;
		this.scheduled_days = scheduled_days;
		this.business_Seats = business_Seats;
		this.non_Business_seats = non_Business_seats;
		this.price = price;
		this.no_Of_Rows = no_Of_Rows;
		this.meal = meal;
	}
	public Flight() {
		super();
		// TODO Auto-generated constructor stub
	}

	}
