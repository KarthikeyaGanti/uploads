package com.airlines.flight.models;

import java.time.LocalDateTime;

public class AirLineExMessage {

	private String message;
	private Class<?> type;
	private LocalDateTime now;
	
	public AirLineExMessage(String message, Class<?> type, LocalDateTime now) {
		super();
		this.message = message;
		this.type = type;
		
		//this(message, type);
		
		this.now = now;
	}
	public AirLineExMessage(String message, Class<?> type) {
		super();
		this.message = message;
		this.type = type;
		this.now = LocalDateTime.now();
	}
	public AirLineExMessage() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Class<?> getType() {
		return type;
	}
	public void setType(Class<?> type) {
		this.type = type;
	}
	public LocalDateTime getNow() {
		return now;
	}
	public void setNow(LocalDateTime now) {
		this.now = now;
	}
	@Override
	public String toString() {
		return "AirLineExMessage [message=" + message + ", type=" + type + ", now=" + now + "]";
	}

}
