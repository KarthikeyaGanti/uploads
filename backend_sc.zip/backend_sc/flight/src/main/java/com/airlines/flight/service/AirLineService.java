package com.airlines.flight.service;

import java.util.List;

import com.airlines.flight.VO.AirlineVO;
import com.airlines.flight.airlineexception.AirLineException;
import com.airlines.flight.entity.Airlines;

public interface AirLineService {
	
	public String addAirLine(Airlines airlines) throws AirLineException;

	public String blockAirLine(String airLineID);

	public String unblockAirLine(String airLineID);

	public Boolean getAirLine(String airLineName);
	
	public String getStatusOfAirline(String airLineName);
	
	public List<AirlineVO> getAllAirLines();
	

}
