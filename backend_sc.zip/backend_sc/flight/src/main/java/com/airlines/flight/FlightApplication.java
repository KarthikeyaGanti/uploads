package com.airlines.flight;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.web.bind.annotation.RequestParam;

import com.airlines.flight.airlineexception.AirLineException;
import com.airlines.flight.entity.Airlines;
import com.airlines.flight.entity.Flight;
import com.airlines.flight.service.AirLineService;
import com.airlines.flight.serviceImpl.FlightServiceImpl;

@SpringBootApplication
@EnableFeignClients
public class FlightApplication implements CommandLineRunner {

	@Autowired
	FlightServiceImpl flightServiceImpl;
	@Autowired
	AirLineService airLineService;
	
	public static void main(String[] args){
		SpringApplication.run(FlightApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

//		LocalDateTime l1= LocalDateTime.of(LocalDate.of(2022,7,23), LocalTime.of(23, 00));
//		Flight flight2= new Flight("Indigo",l1,2000.0,"vizag","hyderabad");
//		flightServiceImpl.addFlight(flight2);
//		addAirLine();
//		addFlight();
	}
	
	public String addAirLine( ) throws AirLineException{
		Airlines airlines= new Airlines();
		airlines.setAirLineName("indigo");
		airlines.setAirLineStatus("Active");
		return airLineService.addAirLine(airlines);
	}
	public String addFlight() {
		LocalDate s_d= LocalDate.of(2022,7,21);
		LocalDate d_d= LocalDate.of(2022,7,22);
		LocalTime s_t=LocalTime.of(19, 00);
		LocalTime d_t=LocalTime.of(10, 00);
		Flight flight= new Flight("spice-jet","hyderabad","vizag", s_d, s_t, d_d, d_t,"ALL DAYS",20,30,2000.0,10,"non -veg");
		return flightServiceImpl.addFlight(flight);
	}
	

}
