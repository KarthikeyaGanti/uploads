package com.airlines.flight.exceptionhandler;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.airlines.flight.airlineexception.AirLineException;
import com.airlines.flight.models.AirLineExMessage;


public class FlightExceptionsControllerAdvice {

	@ExceptionHandler(AirLineException.class)
	public ResponseEntity<?> flightExceptionsHandler(Exception e) {
		System.out.println(e.getMessage());
		e.printStackTrace();
		return new ResponseEntity<AirLineExMessage>(new AirLineExMessage(e.getMessage(), e.getClass()), org.springframework.http.HttpStatus.NOT_FOUND);
	}
}
