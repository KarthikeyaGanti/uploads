package com.airlines.flight.VO;

public class UserVO {

	
	private String uEId;
	private Integer uAge;
	private String uGender;
	private String uName;
	public UserVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserVO(String uEId, Integer uAge, String uGender, String uName) {
		super();
		this.uEId = uEId;
		this.uAge = uAge;
		this.uGender = uGender;
		this.uName = uName;
	}
	public String getuEId() {
		return uEId;
	}
	public void setuEId(String uEId) {
		this.uEId = uEId;
	}
	public Integer getuAge() {
		return uAge;
	}
	public void setuAge(Integer uAge) {
		this.uAge = uAge;
	}
	public String getuGender() {
		return uGender;
	}
	public void setuGender(String uGender) {
		this.uGender = uGender;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}

}
