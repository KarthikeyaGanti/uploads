package com.airlines.flight.VO;

public class AirlineVO {

	private String airLineID;
	private String airLineName;
	private String airLineStatus;
	public String getAirLineStatus() {
		return airLineStatus;
	}
	public void setAirLineStatus(String airLineStatus) {
		this.airLineStatus = airLineStatus;
	}
	public AirlineVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getAirLineID() {
		return airLineID;
	}
	public void setAirLineID(String airLineID) {
		this.airLineID = airLineID;
	}
	public String getAirLineName() {
		return airLineName;
	}
	public void setAirLineName(String airLineName) {
		this.airLineName = airLineName;
	}
	public AirlineVO(String airLineName) {
		super();
		this.airLineName = airLineName;
	}
}
