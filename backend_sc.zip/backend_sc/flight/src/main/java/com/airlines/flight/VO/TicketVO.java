package com.airlines.flight.VO;

public class TicketVO {

			private String pnrNumber;
			private Integer no_Of_tickets;
			private String meal;

			public String getPnrNumber() {
				return pnrNumber;
			}
			public void setPnrNumber(String pnrNumber) {
				this.pnrNumber = pnrNumber;
			}
			public String getMeal() {
				return meal;
			}
			public void setMeal(String meal) {
				this.meal = meal;
			}
			
			public Integer getNo_Of_tickets() {
				return no_Of_tickets;
			}
			public void setNo_Of_tickets(Integer no_Of_tickets) {
				this.no_Of_tickets = no_Of_tickets;
			}
			public TicketVO(String pnrNumber, Integer no_Of_tickets, String meal) {
				super();
				this.pnrNumber = pnrNumber;
				this.no_Of_tickets = no_Of_tickets;
				this.meal = meal;
			}
			public TicketVO() {
				super();
				// TODO Auto-generated constructor stub
			}
			
}


