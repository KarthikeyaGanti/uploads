package com.airlines.flight.serviceImpl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airlines.flight.entity.Flight;
import com.airlines.flight.repositories.FlightsRepo;
import com.airlines.flight.service.AirLineService;
import com.airlines.flight.service.FlightService;

@Service
public class FlightServiceImpl implements FlightService{
	
	static int COUNT_ID=0000;
	@Autowired
	private FlightsRepo flightsRepo;
	@Autowired
	private AirLineService airLineService;
	@Override
	public String addFlight(Flight flight) {
		if(airLineService.getAirLine(flight.getfName())) {
					++COUNT_ID;
					String FID="F000"+COUNT_ID;
					flight.setfID(FID);
					flightsRepo.save(flight);
					return FID;
		}
		else 
			return "NO";
			
	}

	@Override
	public List<Flight> searchFlights(String date,String time, String from, String to, String tripType) {
		List<Flight> searchedFlights=new ArrayList<Flight>();	
		List<Flight> flights=flightsRepo.findAll();
		for(Flight flight:flights) {
			String status= airLineService.getStatusOfAirline(flight.getfName());
			if(status.matches("NO AIRLINE"))
				return searchedFlights;
			else if(status.equalsIgnoreCase("active")) {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				if(flight.getDeparture_time().toString().equals(time)&&flight.getFromPlace().equalsIgnoreCase(from)&&flight.getToPlace().equalsIgnoreCase(to)) {
					if(tripType.equalsIgnoreCase("roundtrip")||tripType.equalsIgnoreCase("two-way")) {
						
						Double price=flight.getPrice();
						flight.setPrice(price*2);	
						System.out.println(price);
					}
					if(flight.getScheduled_days().equalsIgnoreCase("ALL DAYS")) {
						flight.setStart_date(LocalDate.parse(date,formatter));
						flight.setEnd_date(LocalDate.parse(date,formatter).plusDays(1));
						System.out.println(flight.getPrice());
						searchedFlights.add(flight);

					}
					else if(flight.getStart_date().toString().equalsIgnoreCase(date)){
						searchedFlights.add(flight);
					}
					}
				}
			}	
		return searchedFlights;
		}
	

	@Override
	public String updateFlight(Flight flight, int Id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String removeFlight(int Id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Flight> getAllFlights() {
		return flightsRepo.findAll();
	}
	
	public Flight getFlightById(String FID) {
		System.err.println("in flight by id");
		Optional<Flight> optional=flightsRepo.findById(FID);
		return optional.get();
	}
}
