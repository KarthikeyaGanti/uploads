package com.airlines.flight.airlineexception;

public class AirLineException extends Exception{

	public AirLineException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AirLineException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
