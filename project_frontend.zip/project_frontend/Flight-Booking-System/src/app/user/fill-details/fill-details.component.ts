import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user';
import { UserService } from '../service/user.service';
import { ViewTicketComponent } from '../view-ticket/view-ticket.component';

@Component({
  selector: 'app-fill-details',
  templateUrl: './fill-details.component.html',
  styleUrls: ['./fill-details.component.css']
})
export class FillDetailsComponent implements OnInit {
  flightID:any;
  fillDetailsForm:FormGroup;
  message:any;


  constructor(private userService:UserService, private router:Router){
    this.fillDetailsForm= new FormGroup({
      userData:new FormGroup({
        uEId:new FormControl("",[Validators.required]),
        uName:new FormControl("",[Validators.required]),
        uAge:new FormControl("",[Validators.required]),
        uGender:new FormControl("",[Validators.required]),
      }),
      no_of_seats:new FormControl('',[Validators.required]),
      seat_numbers:new FormArray([]),
      meal:new FormControl('',[Validators.required]),
      passengers:new FormArray([])

    })
  }
  
  get passengerControls(){
    return (<FormArray>this.fillDetailsForm.get('passengers')).controls
  }

  get seatControls(){
    return (<FormArray>this.fillDetailsForm.get('seat_numbers')).controls
  }

  ngOnInit(): void {
    let flight=history.state;
    console.log("flight is "+ flight['fID']);
    this.flightID=flight['fID'];
  }

  addPassenger(){
    let index=this.fillDetailsForm.get('passengers')?.value;
    var i =index['length'];
    let noOfSeats=this.fillDetailsForm.get('no_of_seats')?.value;
        if(i<noOfSeats){
        const passenger=new FormControl("",[Validators.required]);
        (<FormArray>this.fillDetailsForm.controls['passengers']).push(new FormGroup({
          passengerName:new FormControl("",[Validators.required]),
          passengerAge:new FormControl("",[Validators.required]),
          passengerGender:new FormControl("",[Validators.required]),
        }));

      }
  }

  addSeats(){
    let index=this.fillDetailsForm.get('seat_numbers')?.value;
    var i =index['length'];
    let noOfSeats=this.fillDetailsForm.get('no_of_seats')?.value;
        if(i<noOfSeats){
        const seat=new FormControl("",[Validators.required]);
        (<FormArray>this.fillDetailsForm.get('seat_numbers')).push(seat);
      }
  }

  proceed(data:any){
    let user:User;
    user=data['userData'];
    console.log("passengers is "+ data['passengers']);
    user.passengerVOs=data['passengers'];
    console.log(user);
    this.userService.bookTicket(user,this.flightID,data["no_of_seats"],data['seat_numbers'],data['meal']).subscribe({
      next:res=>{this.message=res;
        console.log(this.message);
      },
      error:e=>console.log(e)
    })
  }

  
    viewTicket(){
        this.router.navigateByUrl('user/user/viewticket')
    }
}


