import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Flight } from 'src/app/models/flight';

@Component({
  selector: 'app-show-flight',
  templateUrl: './show-flight.component.html',
  styleUrls: ['./show-flight.component.css']
})

export class ShowFlightComponent implements OnInit{

  flightList:any[]=[];
  bookTicketForm:FormGroup;
  constructor(private router:Router) {
    this.bookTicketForm=new FormGroup({
      book:new FormControl('')
    })
   }

  ngOnInit(){
        this.flightList=history.state;
        console.log(this.flightList);
  }

  bookTicket(flightSelected:any){
  let flight=flightSelected;
  console.log(flight)
  this.router.navigateByUrl("/user/user/filldetails",{state:flight});
  }
}
