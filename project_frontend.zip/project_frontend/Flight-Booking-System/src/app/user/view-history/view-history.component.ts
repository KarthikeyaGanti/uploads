import { state } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-view-history',
  templateUrl: './view-history.component.html',
  styleUrls: ['./view-history.component.css']
})
export class ViewHistoryComponent {
  viewHistoryForm:FormGroup;
  bookingHistorty:any[]=[];
  constructor(private userService:UserService ,private router:Router) {
    this.viewHistoryForm=new FormGroup({
      uEID:new FormControl("",[Validators.required])
    })
   }


  viewHistroy(){
    let uEID:any=this.viewHistoryForm.get("uEID")?.value;
    this.userService.getBookingHistory(uEID).subscribe({
      next: (res:any)=>{this.bookingHistorty=res;
      this.router.navigateByUrl('/user/user/bookinghistory',{state:this.bookingHistorty});
    },
      error: e=>console.log(e)
    })
  }

}
