import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-cancel-flight',
  templateUrl: './cancel-flight.component.html',
  styleUrls: ['./cancel-flight.component.css']
})
export class CancelFlightComponent {

  cancelTicketForm:FormGroup;

  message:any="";

  constructor(private userService:UserService) { 
    this.cancelTicketForm=new FormGroup({
      uEID:new FormControl("",[Validators.required]),
      pnrNumber:new FormControl("",[Validators.required])
    })
  }

  cancelTicket(){
    let uEID:any=this.cancelTicketForm.get("uEID")?.value;
    let pnrNumber=this.cancelTicketForm.get("pnrNumber")?.value;
    this.userService.cancelTicket(uEID,pnrNumber).subscribe({
      next: (res:any)=>{this.message=res},
      error:e=>console.log(e)
    })
  }

}
