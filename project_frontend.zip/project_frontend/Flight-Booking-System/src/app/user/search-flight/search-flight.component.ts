import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-search-flight',
  templateUrl: './search-flight.component.html',
  styleUrls: ['./search-flight.component.css']
})
export class SearchFlightComponent  {
  flights:any[]=[];
  
  searchFlightForm:FormGroup
  constructor(private userService:UserService, private router:Router) { 

    this.searchFlightForm=new FormGroup({
      from:new FormControl("",[Validators.required]),
      to:new FormControl("",[Validators.required]),
      startDate:new FormControl("",[Validators.required]),
      startTime:new FormControl("",[Validators.required]),
      tripType:new FormControl("",[Validators.required]),
    })
  }

  searchFlight(){
    let from:any=this.searchFlightForm.get("from")?.value;
    let to:any=this.searchFlightForm.get("to")?.value;
    let startDate:any=this.searchFlightForm.get("startDate")?.value;
    let startTime:any=this.searchFlightForm.get("startTime")?.value;
    let tripType:any=this.searchFlightForm.get("tripType")?.value;
    this.userService.searchFlights(from,to,startDate,startTime,tripType).subscribe({
      next: (res:any)=>{this.flights=res;
            this.router.navigateByUrl('user/user/showflights',{state:this.flights});
      console.log(res)},
      error: e=>console.log(e)
    })

    // this.router.navigate(['/showflights',{state:this.flights}]);
  }
}
