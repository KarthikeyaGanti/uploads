import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { User } from 'src/app/models/user';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  registerUserForm:FormGroup
  constructor(private userService:UserService) { 

    this.registerUserForm=new FormGroup({
      uEID:new FormControl("",[Validators.required]),
      uAge:new FormControl("",[Validators.required]),
      uGender:new FormControl("",[Validators.required]),
      uName:new FormControl("",[Validators.required]),
    })
  }

  register(){
    let user:User=new User;
    user.uAge=this.registerUserForm.get("uAge")?.value;
    user.uEID=this.registerUserForm.get("uEID")?.value;
    user.uGender=this.registerUserForm.get("uGender")?.value;
    user.uName=this.registerUserForm.get("uName")?.value;

    this.userService.register(user).subscribe({
      next: res=>console.log(res),
      error: e=>console.log(e)
    })
  }

}
