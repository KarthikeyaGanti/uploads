import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DetailedTicket } from 'src/app/models/detailedTicket';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-view-ticket',
  templateUrl: './view-ticket.component.html',
  styleUrls: ['./view-ticket.component.css']
})
export class ViewTicketComponent  {

  viewTicketForm:FormGroup;
  ticketDetails:DetailedTicket[]=[];

  constructor(private userService:UserService ,private router:Router) { 
    this.viewTicketForm=new FormGroup({
      uEID:new FormControl("",[Validators.required]),
      pnrNumber:new FormControl("",[Validators.required])
    })
  }

  viewTicket(){
    let uEID:any=this.viewTicketForm.get("uEID")?.value;
    let pnrNumber=this.viewTicketForm.get("pnrNumber")?.value;
    this.userService.viewBookedTIcket(uEID,pnrNumber).subscribe({
      next: (res:any)=>{this.ticketDetails=res;
        this.router.navigateByUrl('/user/user/ticketbooked',{state:this.ticketDetails});
      },
      error:e=>console.log(e)
    })
  }

}
