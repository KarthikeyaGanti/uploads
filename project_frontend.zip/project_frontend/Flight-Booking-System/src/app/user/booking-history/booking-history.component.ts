import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { DetailedTicket } from 'src/app/models/detailedTicket';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-booking-history',
  templateUrl: './booking-history.component.html',
  styleUrls: ['./booking-history.component.css']
})
export class BookingHistoryComponent implements OnInit {
  bookingHistory:any[]=[];
  user:any[]=[];
  passengers:any[]=[];
  flight:any[]=[];
  ticket:any[]=[];
  user1:any;
  bookingHistoryForm:FormGroup;
  constructor() { 
    this.bookingHistoryForm=new FormGroup({})
  }

  ngOnInit(): void {
    this.bookingHistory=history.state;
    console.log(this.bookingHistory);
    for (var index in this.bookingHistory){
      this.user[index]=this.bookingHistory[index].user;
      this.flight[index]=this.bookingHistory[index].flightView;
    }
    console.log(this.flight);
    this.user1=this.user[0];
  }
}
