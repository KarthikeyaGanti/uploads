import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DetailedTicket } from 'src/app/models/detailedTicket';
import { Flight } from 'src/app/models/flight';
import { Passenger } from 'src/app/models/passenger';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-ticket-booked',
  templateUrl: './ticket-booked.component.html',
  styleUrls: ['./ticket-booked.component.css']
})

export class TicketBookedComponent implements OnInit {
  details:any;
  user:any;
  passengers:any[]=[];
  flight:any;
  ticket:any;

  userForm:FormGroup;
  constructor(private fb:FormBuilder) {
    this.userForm=new FormGroup({})
   }
  
  ngOnInit(): void {
    this.details = history.state;
    console.log(this.details)
    this.user=this.details['user'];
    this.passengers=this.details['passengers'];
    console.log(this.passengers);
    this.flight=this.details['flightView'];
    this.ticket=this.details['ticketVO']
  }
}
