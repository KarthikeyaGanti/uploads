import { Injectable } from '@angular/core';
import { HttpClient, HttpParams} from '@angular/common/http';
import { User } from 'src/app/models/user';


@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient:HttpClient) { }

  host:string="http://localhost:300/user";

  register(user:User){
		return this.httpClient.post(this.host+"/register/", user);
	}

  searchFlights(from:any,to:any,startDate:any,startTime:any,tripType:any){
    const options = {
      // let url = `https://server.com/users/detail/${username}`;

      params: new HttpParams().set('date', startDate)
                              .set('time',startTime)
                              .set('from',from)
                              .set('to',to)
                              .set('tripType',tripType)
    };
		return this.httpClient.get(this.host+"/search/"+ startDate+"/"+startTime+"/"+from+"/"+to+"/"+tripType);
	}

  getBookingHistory(uEID:any){
    const options = {
            params: new HttpParams().set('uEID', uEID)
    };
		return this.httpClient.get(`${this.host}/viewhistory/${uEID}`);
  }

  viewBookedTIcket(uEID:any,pnrNumber:any){
    const options = {
      params: new HttpParams().set('uEID', uEID)
                              .set('pnrNumber',pnrNumber)
      };
  return this.httpClient.get(this.host+"/viewbookedticket/"+uEID+"/"+pnrNumber);
    }

  cancelTicket(uEID:any,pnrNumber:any){
    const options = {
      params: new HttpParams().set('uEID', uEID)
                              .set('pnrNumber',pnrNumber)
      };
  return this.httpClient.post(this.host+"/cancelticket/"+uEID+"/"+pnrNumber,options)
  }

  bookTicket(user:User,FID:any,no_of_seats:any,seat_numbers:any,meal:any){
    const options = {
      params: new HttpParams().set('FID', FID)
                              .set('no_of_seats',no_of_seats)
                              .set('seat_numbers',seat_numbers)
                              .set('meal',meal)
      };
  return this.httpClient.post(this.host+"/bookticket/"+FID+"/"+no_of_seats+"/"+seat_numbers+"/"+meal,user)
  }
  
}
