import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchFlightComponent } from './search-flight/search-flight.component';
import { RegisterComponent } from './register/register.component';
import { UserComponent } from './user/user.component';
import { RouterModule, Routes } from '@angular/router';
import { CancelFlightComponent } from './cancel-flight/cancel-flight.component';
import { ViewTicketComponent } from './view-ticket/view-ticket.component';
import { ViewHistoryComponent } from './view-history/view-history.component';
import { ReactiveFormsModule } from "@angular/forms";
import { ShowFlightComponent } from './show-flight/show-flight.component';
import { TicketBookedComponent } from './ticket-booked/ticket-booked.component';
import { HomeComponent } from '../home/home.component';
import { BookingHistoryComponent } from './booking-history/booking-history.component';
import { FillDetailsComponent } from './fill-details/fill-details.component';


const routes:Routes = [
  { path: "home", component: HomeComponent},
  { path: "user", component: UserComponent},
  { path: "user/register", component: RegisterComponent},
  { path: "user/searchflight", component: SearchFlightComponent},
  { path: "user/cancelflight", component: CancelFlightComponent},
  { path: "user/viewticket", component: ViewTicketComponent},
  { path: "user/viewhistory", component: ViewHistoryComponent},
  { path: "user/showflights", component: ShowFlightComponent},
  { path: "user/ticketbooked", component: TicketBookedComponent},
  { path: "user/bookinghistory", component: BookingHistoryComponent},
  { path: "user/filldetails", component: FillDetailsComponent},
  { path: "**", redirectTo: "home" },
];


@NgModule({
  declarations: [
    SearchFlightComponent,
    RegisterComponent,
    UserComponent,
    CancelFlightComponent,
    ViewTicketComponent,
    ViewHistoryComponent,
    ShowFlightComponent,
    TicketBookedComponent,
    BookingHistoryComponent,
    FillDetailsComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ReactiveFormsModule
  ]
})
export class UserModule { }
