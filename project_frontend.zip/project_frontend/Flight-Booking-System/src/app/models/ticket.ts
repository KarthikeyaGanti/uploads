export class Ticket{
    pnrNumber:any;
	no_Of_tickets:any;
	meal:any;
	flightID:any;
	uEID:any;
	seats:any;
}