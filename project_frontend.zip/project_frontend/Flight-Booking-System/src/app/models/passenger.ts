export class Passenger{
    passengerName:any
    passengerAge:any
	passengerGender:any
	uEID:any
	pnrNumber:any
	id:any
}