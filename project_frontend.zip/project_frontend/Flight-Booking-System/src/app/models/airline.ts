export class AirLIne{
    airLineID:any;
    airLineName:any;
    airLineStatus:any;
}