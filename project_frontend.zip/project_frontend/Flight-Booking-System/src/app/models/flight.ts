
export class Flight{
      fID:any;
	  fName:any;
	  fromPlace:any;
	  toPlace:any;
	  start_date:any;
	  departure_time:any;
	  end_date:any;
	  drop_time:any;
	  scheduled_days:any;
	  business_Seats:any;
	  non_Business_seats:any;
	  price:any;
	  no_Of_Rows:any;
	  meal:any;
      
    constructor(
        fName:String,
        fromPlace:String,
        toPlace:String,
        start_date:String,
        departure_time:String,
        end_date:String,
        drop_time:String,
        scheduled_days:String,
        business_Seats:String,
        non_Business_seats:String,
        price:String,
        no_Of_Rows:String,
        meal:String,
   ){
    this.fName=fName;
    this.fromPlace=fromPlace;
    this.toPlace=toPlace;
    this.start_date=start_date;
    this.departure_time=departure_time;
    this.end_date=end_date;
    this.drop_time=drop_time;
    this.scheduled_days=scheduled_days;
    this.business_Seats=business_Seats;
    this.non_Business_seats=non_Business_seats;
    this.price=price;
    this.no_Of_Rows=no_Of_Rows;
    this.meal=meal;
    }
      
}