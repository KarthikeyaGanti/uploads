import { Passenger } from "./passenger";

export class User{
    uName:any;
    uAge:any;
    uGender:any;
    uEID:any
    passengerVOs:any[]=[];
}