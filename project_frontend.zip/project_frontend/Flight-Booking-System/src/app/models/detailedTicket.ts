import { Flight } from "./flight";
import { Passenger } from "./passenger";
import { Ticket } from "./ticket";
import { User } from "./user";

export interface DetailedTicket{
        flightView:Flight;
        ticket:Ticket;
        user:User;
        passengers:Passenger[];
}