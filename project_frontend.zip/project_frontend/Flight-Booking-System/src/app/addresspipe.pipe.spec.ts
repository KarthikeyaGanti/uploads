import { AddresspipePipe } from './addresspipe.pipe';

describe('AddresspipePipe', () => {
  it('create an instance', () => {
    const pipe = new AddresspipePipe();
    expect(pipe).toBeTruthy();
  });
});
