import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import{ RouterModule, Routes } from "@angular/router";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent} from './app.component';
import { MainHeaderComponent } from './main-header/main-header.component';
import { AddresspipePipe } from './addresspipe.pipe';
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { TokenIntercepterServiceService } from './admin/token-intercepter-service.service';
import { HomeComponent } from './home/home.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

const routes:Routes = [
  { path: "home", component: HomeComponent},
  { path: "admin", loadChildren: ()=>import("./admin/admin.module").then(module=>module.AdminModule) },
  { path: "user", loadChildren: ()=>import("./user/user.module").then(module=>module.UserModule) },
  { path: "**", redirectTo: "home" },

  
];

@NgModule({
  declarations: [
    AppComponent,
    MainHeaderComponent,
    AddresspipePipe,
    HomeComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),HttpClientModule, NgbModule
  ],
  providers: [{provide:HTTP_INTERCEPTORS,useClass:TokenIntercepterServiceService,multi:true}],
  // providers:[],
  bootstrap: [AppComponent]
})
export class AppModule { }
