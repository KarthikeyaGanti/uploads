import { Pipe, PipeTransform } from '@angular/core';
import { __importDefault } from 'tslib';

@Pipe({
  name: 'addresspipe'
})
export class AddresspipePipe implements PipeTransform {

  transform(input: String): String {
        var output:String="";
        var address: string[];
        address=input.split(" ");
        console.log(address);
        for(let s of address){
           let k= s.charAt(0).toUpperCase()+s.substring(1,s.length).toLowerCase();
            console.log(k)
            output+=k+" ";
        }
        return output;
  }

}
