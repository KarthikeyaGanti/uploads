import { TestBed } from '@angular/core/testing';

import { TokenIntercepterServiceService } from './token-intercepter-service.service';

describe('TokenIntercepterServiceService', () => {
  let service: TokenIntercepterServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TokenIntercepterServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
