import { Injectable } from '@angular/core';
import { HttpClient,HttpInterceptor, HttpParams} from '@angular/common/http';
import { Admin } from './login/admin';

@Injectable({
  providedIn: 'root'
})
export class AdminService{

  constructor(private httpClient:HttpClient){}

  // host:string = "https://jsonplaceholder.typicode.com/users";
  host:string="http://localhost:2005/admin";



	loginAdmin(admin:Admin){
    console.log(admin);
    return this.httpClient.post(this.host,admin);
	}

  addAirline(airline:any){
		return this.httpClient.post(this.host+"/addairline/", airline);
    }
  
  getAllAirLines(){
    return this.httpClient.get(this.host+"/allairlines");
  }

  blockAirLine(airLineId:any){
      // params: new HttpParams().set('airLineID', airLineId)
     let  id=this.filter(airLineId);
     console.log(id); 
    return this.httpClient.post(this.host+"/blockairline/"+airLineId,airLineId)
  }

  
  unblockAirLine(airLineId:String){
    return this.httpClient.post(this.host+"/unblockairline/"+airLineId,airLineId);
  }

  addFlight(flight:any){
    return this.httpClient.post(this.host+"/addflight", flight);

  }

  filter(string:String){
    let output='';
    let input=string.split(" ");
    for(let s of input){
      output=output+s;
    }
    return output;
  }

}
