import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AirLIne } from 'src/app/models/airline';
import { AdminService } from '../admin.service';
@Component({
  selector: 'app-unblockairline',
  templateUrl: './unblockairline.component.html',
  styleUrls: ['./unblockairline.component.css']
})
export class UnblockairlineComponent implements OnInit {
  unblockAirLineForm:FormGroup;
  message:String="";
  constructor(private adminService:AdminService) {
    this.unblockAirLineForm=new FormGroup({
      airLine:new FormControl("",[Validators.required])
    });
   }


  airlines:AirLIne[]=[];
  airLineStatus:any="";

  ngOnInit(): void {
    this.loadAllAirLines();
  }

  loadAllAirLines(){
    this.adminService.getAllAirLines().subscribe({
      next: (res:any)=>{
          // console.log(res);
          this.airlines = res;
          // console.log(res)
      },
      error: (e)=>{
          console.log(e)
      }
  })

  }

  unblockAirLine(){
    let airLineId:String=this.unblockAirLineForm.get("airLine")?.value;
    this.adminService.unblockAirLine(airLineId).subscribe(
      {
        next:(res:any)=>{this.message=res},
        error:e=>console.log(e)
      }
    )
  }

}
