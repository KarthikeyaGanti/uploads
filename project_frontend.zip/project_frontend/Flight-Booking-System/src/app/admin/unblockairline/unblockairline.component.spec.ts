import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnblockairlineComponent } from './unblockairline.component';

describe('UnblockairlineComponent', () => {
  let component: UnblockairlineComponent;
  let fixture: ComponentFixture<UnblockairlineComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnblockairlineComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnblockairlineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
