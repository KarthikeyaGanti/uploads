import { TokenPipe } from './token.pipe';

describe('TokenPipe', () => {
  it('create an instance', () => {
    const pipe = new TokenPipe();
    expect(pipe).toBeTruthy();
  });
});
