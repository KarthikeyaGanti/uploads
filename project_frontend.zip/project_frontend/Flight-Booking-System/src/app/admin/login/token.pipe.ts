import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'token'
})
export class TokenPipe implements PipeTransform {

  transform(token: String): String {
      var output:String="";
      var tokenarray:String[];
      let temp:String;
      tokenarray=token.split(":");
      output=tokenarray[1];
      temp=output.substring(1,output.length-2);
    return temp;
  }

}
