export class Admin{
    private username:String;
    private password:String;
    constructor(username:String,
          password:String){
             this.username=username;
             this.password=password
         }

public set setUsername(username:String){
    this.username=username;
}

public set setPassword(password:String){
    this.password=password;
}

public get getusername(){
    return this.username;
}
public get getPassword(){
    return this.password;
}

}