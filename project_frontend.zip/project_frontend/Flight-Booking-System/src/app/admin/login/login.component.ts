import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { Admin } from './admin';
import { TokenPipe } from './token.pipe';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  message:string = "";
  loginForm:FormGroup;

  constructor(private adminservice:AdminService  , private router:Router){
      this.loginForm = new FormGroup({
          username: new FormControl("", [
              Validators.required,
          ]), 
          password: new FormControl("", [
            Validators.required,
          ])
      });
  }

  getLogin(){
      //console.log(this.loginForm);
      //console.log("Value: "+JSON.stringify(this.loginForm.value));
      //console.log("Valid: "+this.loginForm.valid)

      if(this.loginForm.valid){
          console.log("Send request to get login");
          this.message = "";
      } else {
          console.log("Invalid data");
          this.message = "Bad request";
      }
      let admin:Admin= new Admin(this.loginForm.get("username")?.value,this.loginForm.get("password")?.value)
      // console.log(admin.getusername);
      // co nsole.log(admin.getPassword);
          this.adminservice.loginAdmin(admin).subscribe(
          {
            next: (res:any)=>{
              console.log(res);
              localStorage.setItem('token',res.token);
              alert('Admin logged in');
              this.router.navigateByUrl("admin/admin");
            },
            error: (e:any)=>{
              console.log(e);
              return e;
            }
          }
        )
      }
    }
  

