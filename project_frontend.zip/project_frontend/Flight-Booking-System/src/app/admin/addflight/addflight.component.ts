import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Flight } from 'src/app/models/flight';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-addflight',
  templateUrl: './addflight.component.html',
  styleUrls: ['./addflight.component.css']
})
export class AddflightComponent implements OnInit {
  addFlightForm:FormGroup;
  airlines:any[]=[];
  message:any;
  pricePattern="[0-9]+";
  constructor(private adminService:AdminService) {
    this.addFlightForm=new FormGroup(
    {
      airLineName:new FormControl("",[Validators.required]),
      from:new FormControl("",[Validators.required]),
      to:new FormControl("",[Validators.required]),
      startDate:new FormControl("",[Validators.required]),
      startTime:new FormControl("",[Validators.required]),
      dropDate:new FormControl("",[Validators.required]),
      dropTime:new FormControl("",[Validators.required]),
      scheduledDays:new FormControl("",[Validators.required]),
      businessSeats:new FormControl("",[Validators.required,Validators.max(50)]),
      nonBusinessSeats:new FormControl("",[Validators.required,Validators.max(50)]),
      price:new FormControl("",[Validators.required,Validators.pattern(this.pricePattern)]),
      no_of_rows:new FormControl("",[Validators.required,Validators.max(25)]),
      meal:new FormControl("",[Validators.required]),
    }
    )
   }

  ngOnInit(): void {
    this.loadAllAirLines();
  }

  addFlight(){
    let airLineName=this.addFlightForm.get("airLineName")?.value;
    let from = this.addFlightForm.get("from")?.value;
    let to=this.addFlightForm.get("to")?.value;
    let startDate=this.addFlightForm.get("startDate")?.value;
    let startTime=this.addFlightForm.get("startTime")?.value;
    let dropDate=this.addFlightForm.get("dropDate")?.value;   
    let dropTime=this.addFlightForm.get("dropTime")?.value;
    let scheduledDays=this.addFlightForm.get("scheduledDays")?.value;
    let businessSeats=this.addFlightForm.get("businessSeats")?.value;
    let nonBusinessSeats=this.addFlightForm.get("nonBusinessSeats")?.value;
    let price=this.addFlightForm.get("price")?.value;
    let no_of_rows=this.addFlightForm.get("no_of_rows")?.value;
    let meal=this.addFlightForm.get("meal")?.value;

    let flight:Flight=new Flight(airLineName,from,to,startDate,startTime,dropDate,dropTime,scheduledDays,
      businessSeats,nonBusinessSeats,price,no_of_rows,meal);

      this.adminService.addFlight(flight).subscribe({
        next:res=>this.message=res,
        error: e=>console.log(e)
      })
  }

  loadAllAirLines(){
    this.adminService.getAllAirLines().subscribe({
      next: (res:any)=>{
          // console.log(res);
          this.airlines = res;
          // console.log(res)
      },
      error: (e)=>{
          console.log(e)
      }
  })

  }

}
