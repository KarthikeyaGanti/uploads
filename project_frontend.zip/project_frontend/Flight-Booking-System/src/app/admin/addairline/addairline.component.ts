import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AirLIne } from 'src/app/models/airline';
import { AdminService } from '../admin.service';
import { SecurityService } from '../security/security.service';

@Component({
  selector: 'app-addairline',
  templateUrl: './addairline.component.html',
  styleUrls: ['./addairline.component.css']
})
export class AddairlineComponent implements OnInit{
  message:String="";
  addairlineform:FormGroup;
  user:any = {
    name: ""
  }
  constructor(private adminservice:AdminService,private securityService:SecurityService) {
    this.addairlineform = new FormGroup({
      airLineName: new FormControl("", [
            Validators.required,
        ]), 
        airLineStatus: new FormControl("", [
          Validators.required,
        ])
    });
}

ngOnInit(){
  this.user = this.securityService.user;
}

  addAirline(){
      let airlineName=this.addairlineform.get("airLineName")?.value;
      let airLineStatus=this.addairlineform.get("airLineStatus")?.value;
      console.log(airLineStatus);
      let airline:AirLIne= new AirLIne;
      airline.airLineName=airlineName;
      airline.airLineStatus=airLineStatus;
      this.adminservice.addAirline(airline).subscribe({
        next:(res:any)=>{
          this.message=res;
      },
        error:(e:any)=>{
          console.log(e);
        }
      })
  }


}
