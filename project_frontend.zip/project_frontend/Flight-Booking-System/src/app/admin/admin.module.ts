import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { AddairlineComponent } from './addairline/addairline.component';
import { BlockairlineComponent } from './blockairline/blockairline.component';
import { UnblockairlineComponent } from './unblockairline/unblockairline.component';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { AddflightComponent } from './addflight/addflight.component';
import { ReactiveFormsModule } from "@angular/forms";
import { TokenPipe } from './login/token.pipe';
import { AppComponent } from '../app.component';
import { MainHeaderComponent } from '../main-header/main-header.component';
import { ValidSecurityGuard } from './security/valid-security-guard';
// import { TokenIntercepterServiceService } from './token-intercepter-service.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';


const routes:Routes = [
  { path: "admin", component: AdminComponent},
  { path: "login", component: LoginComponent},
  { path: "admin/addairline", component: AddairlineComponent,canActivate: [ValidSecurityGuard]},
  { path: "admin/blockairline", component: BlockairlineComponent, canActivate: [ValidSecurityGuard]},
  { path: "admin/unblockairline", component: UnblockairlineComponent, canActivate: [ValidSecurityGuard]},
  { path: "admin/addflight", component: AddflightComponent,canActivate: [ValidSecurityGuard]},
  { path: "**", redirectTo: "login"},

];


@NgModule({
  declarations: [
    AdminComponent,
    LoginComponent,
    AddairlineComponent,
    BlockairlineComponent,
    UnblockairlineComponent,
    AddflightComponent,
    TokenPipe,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ReactiveFormsModule,
  ],
  // providers: [{provide:HTTP_INTERCEPTORS,useClass:TokenIntercepterServiceService,multi:true}],
})
export class AdminModule { }
