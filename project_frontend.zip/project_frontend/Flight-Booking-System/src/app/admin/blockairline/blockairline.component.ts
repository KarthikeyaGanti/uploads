import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AirLIne } from 'src/app/models/airline';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-blockairline',
  templateUrl: './blockairline.component.html',
  styleUrls: ['./blockairline.component.css']
})
export class BlockairlineComponent implements OnInit {
  
  blockAirLineForm:FormGroup;
  airlines:AirLIne[]=[];
  message:String="";

  constructor(private adminService:AdminService) {
    this.blockAirLineForm=new FormGroup({
      airLine:new FormControl("",[Validators.required])
    });
   }



  ngOnInit(): void {
    this.loadAllAirLines();
  }

  loadAllAirLines(){
    this.adminService.getAllAirLines().subscribe({
      next: (res:any)=>{
          //  console.log(res);
          this.airlines = res;
          // console.log(res)
      },
      error: (e)=>{
          console.log(e)
      }
  })

  }

  blockAirLine(){
    let airLineId:String=this.blockAirLineForm.get("airLine")?.value;
    console.log(airLineId);
    this.adminService.blockAirLine(airLineId).subscribe(
      {
        next:(res:any)=>{this.message=res;
        alert(res)},
        error:e=>console.log(e)
      }
    )
  }

}
